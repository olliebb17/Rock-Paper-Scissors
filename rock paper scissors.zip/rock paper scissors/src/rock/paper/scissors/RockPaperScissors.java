
package rock.paper.scissors;
import java.util.Scanner;
import java.util.Random;
public class RockPaperScissors {

   
    public static void main(String[] args) {
        Random random = new Random();
        Scanner input = new Scanner(System.in);
        int rand = (int)(Math.random()*3);
        int PlayerPoint = 0;
        int ComputerPoint = 0;
        int H = 0;
        String opponentMove = "";
        String opponentMove2 = "";
        int rand2 = (int) (Math.random()*3);
        
        System.out.println("Rock - 1, Paper - 2 or Scissors - 3");
        int Selected = input.nextInt();
            switch (Selected){
            case (1):
                System.out.println("you have picked Rock");
                if(rand == 0) {
                    opponentMove = "rock";
                } else if(rand == 1) {
                    opponentMove = "paper";
                } else {
                    opponentMove = "scissors";
				}
                if (opponentMove.equals("rock")){
                    System.out.println("opponent chose "+opponentMove+", A tie");
                }
                if (opponentMove.equals("paper")){
                    System.out.println("Opponent chose "+opponentMove+", one point awareded to Computer");
                    ComputerPoint++;
                }
                if (opponentMove.equals("scissors")){
                    System.out.println("Opponent chose "+opponentMove+", one point awareded to Player");
                    PlayerPoint++;
                }
                break;
                
            case (2):
                System.out.println("you have picked Paper");
                if(rand == 0) {
                    opponentMove = "rock";
                } else if(rand == 1) {
                    opponentMove = "paper";
                } else {
                    opponentMove = "scissors";
				}
                if (opponentMove.equals("rock")){
                    System.out.println("Player wins and gets a point");
                    PlayerPoint++;
                }
                if (opponentMove.equals("paper")){
                    System.out.println("Computer and Player gets a point");
                    ComputerPoint++;
                    PlayerPoint++;
                }
                if (opponentMove.equals("scissors")){
                    System.out.println("one point awarded to Computer");
                    ComputerPoint++;
                }
                break;
                
            case (3):
                System.out.println("you have picked Scissors");
                 if(rand == 0) {
                    opponentMove = "rock";
                } else if(rand == 1) {
                    opponentMove = "paper";
                } else {
                    opponentMove = "scissors";
				}
                if (opponentMove.equals("rock")){
                    System.out.println("Player wins and gets a point");
                    PlayerPoint++;
                }
                if (opponentMove.equals("paper")){
                    System.out.println("Player gets a point");
                    PlayerPoint++;
                }
                if (opponentMove.equals("scissors")){
                    System.out.println("Computer and player gets a point");
                    ComputerPoint++;
                    PlayerPoint++;
                }
                break;
                
            default:
                System.out.println("not a valid choice");
               System.exit(H);
                break;
        
    }
        System.out.println("Do you want to play again, Yes or No");
        String QYN = input.next();
        if(QYN.equals("Yes")){
            System.out.println("Rock - 1, Paper - 2 or Scissors - 3");
        int Selected2 = input.nextInt();
            switch (Selected2){
            case (1):
                if(rand2 == 0) {
                    opponentMove2 = "rock";
                } else if(rand == 1) {
                    opponentMove2 = "paper";
                } else {
                    opponentMove2 = "scissors";
				}
                System.out.println("you have picked Rock");
                if (opponentMove2.equals("rock")){
                    System.out.println("opponent chose "+opponentMove2+" A tie");
                }
                if (opponentMove2.equals("paper")){
                    System.out.println("Opponent chose "+opponentMove2+" one point awareded to Computer");
                    ComputerPoint++;
                }
                if (opponentMove2.equals("scissors")){
                    System.out.println("Opponent chose "+opponentMove2+" one point awareded to Player");
                    PlayerPoint++;
                }
                break;
                
            case (2):
                System.out.println("you have picked Paper");
                if(rand2 == 0) {
                    opponentMove = "rock";
                } else if(rand == 1) {
                    opponentMove = "paper";
                } else {
                    opponentMove = "scissors";
				}
                if (opponentMove.equals("rock")){
                    System.out.println("Player wins and gets a point");
                    PlayerPoint++;
                }
                if (opponentMove.equals("paper")){
                    System.out.println("Computer and Player gets a point");
                    ComputerPoint++;
                    PlayerPoint++;
                }
                if (opponentMove.equals("scissors")){
                    System.out.println("one point awarded to Computer");
                    ComputerPoint++;
                }
                break;
                
            case (3):
                System.out.println("you have picked Scissors");
                 if(rand2 == 0) {
                    opponentMove = "rock";
                } else if(rand == 1) {
                    opponentMove = "paper";
                } else {
                    opponentMove = "scissors";
				}
                if (opponentMove.equals("rock")){
                    System.out.println("Player wins and gets a point");
                    PlayerPoint++;
                }
                if (opponentMove.equals("paper")){
                    System.out.println("Player gets a point");
                    PlayerPoint++;
                }
                if (opponentMove.equals("scissors")){
                    System.out.println("Computer and player gets a point");
                    ComputerPoint++;
                    PlayerPoint++;
                }
                break;
                
            default:
                System.out.println("not a valid choice");
                System.exit(H);
                break;
        }
            
        }
        System.out.println("Final round");
        System.out.println("Decide whether or not you should pick up the grenade, Yes or No");
        String finalround = input.next();
       if(finalround.equals("Yes")){
           int grenade = random.nextInt(1);
           if (grenade==1){
           System.out.println("Player is awarded a point");
           PlayerPoint++;
       }
           if(grenade==0){
               System.out.println("Opponent is awarded a point");
               ComputerPoint++;
           }
           else{
               System.out.println("safe");
           }
       
    }
       if (ComputerPoint>PlayerPoint){
           System.out.println("opponent had "+ComputerPoint+" Computer wins"); 
       }
        
        if (ComputerPoint<PlayerPoint){
            System.out.println("You had "+PlayerPoint+" Player wins");
        }
        if(ComputerPoint == PlayerPoint){
            System.out.println("It was a tie "+ PlayerPoint+", " + ComputerPoint );
        }
        }
       
           
        
        }

        
        
    
    

